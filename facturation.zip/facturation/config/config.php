<?php
define('APP_NAME', 'Système de Facturation');
define('APP_VERSION', '1.0');

define('TVA_TAUX', 0.18);
define('DEVISE', 'CDF');

define('DATA_DIR', __DIR__ . '/../data/');
define('PRODUITS_FILE', DATA_DIR . 'produits.json');
define('FACTURES_FILE', DATA_DIR . 'factures.json');
define('UTILISATEURS_FILE', DATA_DIR . 'utilisateurs.json');

define('SESSION_NAME', 'facturation_session');
define('SESSION_LIFETIME', 3600);

define('ROLES', ['super_admin', 'manager', 'caissier']);

ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Africa/Kinshasa');
