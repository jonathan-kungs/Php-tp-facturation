<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth/session.php';
require_once __DIR__ . '/../includes/fonctions-auth.php';
require_once __DIR__ . '/../includes/fonctions-factures.php';
require_once __DIR__ . '/../includes/fonctions-produits.php';

$utilisateur = exiger_role(['manager', 'super_admin']);
$titre_page = 'Rapport Mensuel';

$annee = (int)($_GET['annee'] ?? date('Y'));
$mois = (int)($_GET['mois'] ?? date('n'));

$factures_mois = factures_du_mois($annee, $mois);
$total_ht = array_sum(array_column($factures_mois, 'total_ht'));
$total_tva = array_sum(array_column($factures_mois, 'tva'));
$total_ttc = array_sum(array_column($factures_mois, 'total_ttc'));

$par_jour = [];
foreach ($factures_mois as $f) {
    $j = $f['date'];
    if (!isset($par_jour[$j])) $par_jour[$j] = ['nb' => 0, 'total' => 0];
    $par_jour[$j]['nb']++;
    $par_jour[$j]['total'] += $f['total_ttc'];
}
ksort($par_jour);

$noms_mois = ['', 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
    'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

include __DIR__ . '/../includes/header.php';
?>

<div class="page-header no-print">
    <h2>📅 Rapport Mensuel</h2>
    <div>
        <form method="GET" action="" style="display:inline-flex; gap:.5rem; align-items:center;">
            <select name="mois">
                <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?= $m ?>" <?= $m === $mois ? 'selected' : '' ?>><?= $noms_mois[$m] ?></option>
                <?php endfor; ?>
            </select>
            <input type="number" name="annee" value="<?= $annee ?>" min="2020" max="<?= date('Y') ?>" style="width:90px;">
            <button type="submit" class="btn btn-secondary">Afficher</button>
        </form>
        <button onclick="window.print()" class="btn btn-outline">🖨 Imprimer</button>
    </div>
</div>

<div class="rapport-document">
    <div class="rapport-entete">
        <h2>📅 Rapport Mensuel — <?= $noms_mois[$mois] ?> <?= $annee ?></h2>
        <p>Généré le <?= date('d/m/Y à H:i') ?></p>
    </div>

    <div class="stats-grid" style="margin:1.5rem 0;">
        <div class="stat-card stat-blue">
            <div class="stat-icon">🧾</div>
            <div class="stat-info">
                <div class="stat-value"><?= count($factures_mois) ?></div>
                <div class="stat-label">Factures émises</div>
            </div>
        </div>
        <div class="stat-card stat-green">
            <div class="stat-icon">💰</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_ht) ?></div>
                <div class="stat-label">Total HT</div>
            </div>
        </div>
        <div class="stat-card stat-orange">
            <div class="stat-icon">🏦</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_tva) ?></div>
                <div class="stat-label">TVA collectée</div>
            </div>
        </div>
        <div class="stat-card stat-purple">
            <div class="stat-icon">💵</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_ttc) ?></div>
                <div class="stat-label">Total TTC</div>
            </div>
        </div>
    </div>

    <?php if (!empty($par_jour)): ?>
    <h3>Activité par jour</h3>
    <table class="table">
        <thead><tr><th>Date</th><th>Nb factures</th><th>Total TTC</th></tr></thead>
        <tbody>
            <?php foreach ($par_jour as $date => $stat): ?>
            <tr>
                <td><?= htmlspecialchars($date) ?></td>
                <td><?= $stat['nb'] ?></td>
                <td class="montant"><?= formater_prix($stat['total']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state"><p>Aucune facture pour ce mois.</p></div>
    <?php endif; ?>
</div>

<style>
@media print { .no-print, .navbar, .footer { display: none !important; } body { background: white; } }
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
