<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth/session.php';
require_once __DIR__ . '/../includes/fonctions-auth.php';
require_once __DIR__ . '/../includes/fonctions-factures.php';
require_once __DIR__ . '/../includes/fonctions-produits.php';

$utilisateur = exiger_role(['manager', 'super_admin']);
$titre_page = 'Rapport Journalier';

$date = $_GET['date'] ?? date('Y-m-d');
$factures = charger_factures();
$factures_jour = array_filter($factures, fn($f) => $f['date'] === $date);
$total_ht = array_sum(array_column($factures_jour, 'total_ht'));
$total_tva = array_sum(array_column($factures_jour, 'tva'));
$total_ttc = array_sum(array_column($factures_jour, 'total_ttc'));

$articles_vendus = [];
foreach ($factures_jour as $f) {
    foreach ($f['articles'] as $a) {
        $cb = $a['code_barre'];
        if (!isset($articles_vendus[$cb])) {
            $articles_vendus[$cb] = ['nom' => $a['nom'], 'quantite' => 0, 'total_ht' => 0];
        }
        $articles_vendus[$cb]['quantite'] += $a['quantite'];
        $articles_vendus[$cb]['total_ht'] += $a['sous_total_ht'];
    }
}
uasort($articles_vendus, fn($a, $b) => $b['quantite'] <=> $a['quantite']);

include __DIR__ . '/../includes/header.php';
?>

<div class="page-header no-print">
    <h2>📊 Rapport Journalier</h2>
    <div>
        <form method="GET" action="" style="display:inline-flex; gap:.5rem; align-items:center;">
            <input type="date" name="date" value="<?= htmlspecialchars($date) ?>" max="<?= date('Y-m-d') ?>">
            <button type="submit" class="btn btn-secondary">Afficher</button>
        </form>
        <button onclick="window.print()" class="btn btn-outline">🖨 Imprimer</button>
    </div>
</div>

<div class="rapport-document">
    <div class="rapport-entete">
        <h2>📊 Rapport Journalier — <?= htmlspecialchars($date) ?></h2>
        <p>Généré le <?= date('d/m/Y à H:i') ?> par <?= htmlspecialchars($utilisateur['nom_complet']) ?></p>
    </div>

    <div class="stats-grid" style="margin:1.5rem 0;">
        <div class="stat-card stat-blue">
            <div class="stat-icon">🧾</div>
            <div class="stat-info">
                <div class="stat-value"><?= count($factures_jour) ?></div>
                <div class="stat-label">Factures émises</div>
            </div>
        </div>
        <div class="stat-card stat-green">
            <div class="stat-icon">💰</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_ht) ?></div>
                <div class="stat-label">Total HT</div>
            </div>
        </div>
        <div class="stat-card stat-orange">
            <div class="stat-icon">🏦</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_tva) ?></div>
                <div class="stat-label">TVA collectée</div>
            </div>
        </div>
        <div class="stat-card stat-purple">
            <div class="stat-icon">💵</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_ttc) ?></div>
                <div class="stat-label">Total TTC (recettes)</div>
            </div>
        </div>
    </div>

    <?php if (!empty($articles_vendus)): ?>
    <h3>Top produits vendus</h3>
    <table class="table">
        <thead>
            <tr><th>Produit</th><th>Qté vendue</th><th>Total HT</th></tr>
        </thead>
        <tbody>
            <?php foreach ($articles_vendus as $cb => $a): ?>
            <tr>
                <td><?= htmlspecialchars($a['nom']) ?></td>
                <td><?= $a['quantite'] ?></td>
                <td class="montant"><?= formater_prix($a['total_ht']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php if (!empty($factures_jour)): ?>
    <h3 style="margin-top:2rem;">Détail des factures</h3>
    <table class="table">
        <thead>
            <tr><th>ID Facture</th><th>Heure</th><th>Caissier</th><th>Articles</th><th>Total HT</th><th>TVA</th><th>Net à payer</th></tr>
        </thead>
        <tbody>
            <?php foreach ($factures_jour as $f): ?>
            <tr>
                <td><code><?= htmlspecialchars($f['id_facture']) ?></code></td>
                <td><?= htmlspecialchars($f['heure']) ?></td>
                <td><?= htmlspecialchars($f['caissier']) ?></td>
                <td><?= count($f['articles']) ?></td>
                <td class="montant"><?= formater_prix($f['total_ht']) ?></td>
                <td class="montant"><?= formater_prix($f['tva']) ?></td>
                <td class="montant"><strong><?= formater_prix($f['total_ttc']) ?></strong></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="empty-state">
        <p>Aucune facture enregistrée pour cette date.</p>
    </div>
    <?php endif; ?>
</div>

<style>
@media print {
    .no-print, .navbar, .footer { display: none !important; }
    body { background: white; }
}
</style>

<?php include __DIR__ . '/../includes/footer.php'; ?>
