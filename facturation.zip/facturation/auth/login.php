<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth/session.php';
require_once __DIR__ . '/../includes/fonctions-auth.php';

if (utilisateur_connecte()) {
    header('Location: ../index.php');
    exit;
}

$erreur = '';
$identifiant = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';

    if (empty($identifiant) || empty($mot_de_passe)) {
        $erreur = "Veuillez remplir tous les champs.";
    } else {
        $utilisateur = authentifier($identifiant, $mot_de_passe);
        if ($utilisateur) {
            $_SESSION['utilisateur'] = $utilisateur;
            header('Location: ../index.php');
            exit;
        } else {
            $erreur = "Identifiant ou mot de passe incorrect.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion — <?= APP_NAME ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="login-body">
<div class="login-container">
    <div class="login-card">
        <div class="login-logo">
            <div class="logo-icon">🏪</div>
            <h1><?= APP_NAME ?></h1>
            <p>Système de caisse informatisé</p>
        </div>

        <?php if ($erreur): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erreur) ?></div>
        <?php endif; ?>

        <form method="POST" action="" class="login-form">
            <div class="form-group">
                <label for="identifiant">Identifiant</label>
                <input type="text" id="identifiant" name="identifiant"
                       value="<?= htmlspecialchars($identifiant) ?>"
                       placeholder="votre.identifiant"
                       required autofocus>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <div class="password-wrapper">
                    <input type="password" id="mot_de_passe" name="mot_de_passe"
                           placeholder="••••••••" required>
                    <button type="button" class="toggle-password" onclick="togglePassword()">👁</button>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-full">Se connecter</button>
        </form>

        <div class="login-hint">
            <small>Compte par défaut : <strong>admin</strong> / <strong>password</strong></small>
        </div>
    </div>
</div>
<script>
function togglePassword() {
    const input = document.getElementById('mot_de_passe');
    input.type = input.type === 'password' ? 'text' : 'password';
}
</script>
</body>
</html>
