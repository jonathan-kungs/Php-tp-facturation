<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/auth/session.php';
require_once __DIR__ . '/includes/fonctions-auth.php';
require_once __DIR__ . '/includes/fonctions-factures.php';
require_once __DIR__ . '/includes/fonctions-produits.php';

$utilisateur = exiger_connexion();
$role = $utilisateur['role'];
$titre_page = 'Tableau de bord';

$factures_jour = factures_du_jour();
$total_jour = total_factures($factures_jour);
$nb_produits = count(charger_produits());
$nb_factures = count($factures_jour);

include __DIR__ . '/includes/header.php';
?>

<div class="dashboard">
    <div class="page-header">
        <h2>👋 Bienvenue, <?= htmlspecialchars($utilisateur['nom_complet']) ?></h2>
        <p class="text-muted"><?= date('l d F Y') ?> — <?= libelle_role($role) ?></p>
    </div>

    <div class="stats-grid">
        <div class="stat-card stat-blue">
            <div class="stat-icon">🧾</div>
            <div class="stat-info">
                <div class="stat-value"><?= $nb_factures ?></div>
                <div class="stat-label">Factures aujourd'hui</div>
            </div>
        </div>
        <div class="stat-card stat-green">
            <div class="stat-icon">💰</div>
            <div class="stat-info">
                <div class="stat-value"><?= formater_prix($total_jour) ?></div>
                <div class="stat-label">Recettes du jour</div>
            </div>
        </div>
        <?php if (in_array($role, ['manager', 'super_admin'])): ?>
        <div class="stat-card stat-orange">
            <div class="stat-icon">📦</div>
            <div class="stat-info">
                <div class="stat-value"><?= $nb_produits ?></div>
                <div class="stat-label">Produits enregistrés</div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="quick-actions">
        <h3>Actions rapides</h3>
        <div class="actions-grid">
            <a href="modules/facturation/nouvelle-facture.php" class="action-card">
                <span class="action-icon">🧾</span>
                <span>Nouvelle Facture</span>
            </a>
            <?php if (in_array($role, ['manager', 'super_admin'])): ?>
            <a href="modules/produits/enregistrer.php" class="action-card">
                <span class="action-icon">➕</span>
                <span>Ajouter un produit</span>
            </a>
            <a href="modules/produits/liste.php" class="action-card">
                <span class="action-icon">📋</span>
                <span>Liste des produits</span>
            </a>
            <a href="rapports/rapport-journalier.php" class="action-card">
                <span class="action-icon">📊</span>
                <span>Rapport journalier</span>
            </a>
            <?php endif; ?>
            <?php if ($role === 'super_admin'): ?>
            <a href="modules/admin/gestion-comptes.php" class="action-card">
                <span class="action-icon">👥</span>
                <span>Gestion des comptes</span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!empty($factures_jour)): ?>
    <div class="recent-invoices">
        <h3>Factures du jour</h3>
        <table class="table">
            <thead>
                <tr>
                    <th>ID Facture</th>
                    <th>Heure</th>
                    <th>Caissier</th>
                    <th>Articles</th>
                    <th>Total TTC</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (array_reverse(array_values($factures_jour)) as $f): ?>
                <tr>
                    <td><code><?= htmlspecialchars($f['id_facture']) ?></code></td>
                    <td><?= htmlspecialchars($f['heure']) ?></td>
                    <td><?= htmlspecialchars($f['caissier']) ?></td>
                    <td><?= count($f['articles']) ?></td>
                    <td class="montant"><?= formater_prix($f['total_ttc']) ?></td>
                    <td>
                        <a href="modules/facturation/afficher-facture.php?id=<?= urlencode($f['id_facture']) ?>"
                           class="btn btn-sm btn-outline">Voir</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
