<?php
require_once __DIR__ . '/../config/config.php';

function charger_produits() {
    if (!file_exists(PRODUITS_FILE)) return [];
    $json = file_get_contents(PRODUITS_FILE);
    return json_decode($json, true) ?: [];
}

function sauvegarder_produits($produits) {
    file_put_contents(PRODUITS_FILE, json_encode(array_values($produits), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function trouver_produit_par_code($code_barre) {
    $produits = charger_produits();
    foreach ($produits as $p) {
        if ($p['code_barre'] === $code_barre) return $p;
    }
    return null;
}

function enregistrer_produit($donnees) {
    $erreurs = valider_produit($donnees);
    if (!empty($erreurs)) return $erreurs;

    $produits = charger_produits();
    foreach ($produits as &$p) {
        if ($p['code_barre'] === $donnees['code_barre']) {
            $p['nom'] = $donnees['nom'];
            $p['prix_unitaire_ht'] = (float)$donnees['prix_unitaire_ht'];
            $p['date_expiration'] = $donnees['date_expiration'];
            $p['quantite_stock'] = (int)$donnees['quantite_stock'];
            sauvegarder_produits($produits);
            return [];
        }
    }

    $produits[] = [
        'code_barre' => $donnees['code_barre'],
        'nom' => trim($donnees['nom']),
        'prix_unitaire_ht' => (float)$donnees['prix_unitaire_ht'],
        'date_expiration' => $donnees['date_expiration'],
        'quantite_stock' => (int)$donnees['quantite_stock'],
        'date_enregistrement' => date('Y-m-d')
    ];
    sauvegarder_produits($produits);
    return [];
}

function valider_produit($donnees) {
    $erreurs = [];
    if (empty($donnees['code_barre'])) $erreurs[] = "Le code-barres est obligatoire.";
    if (empty(trim($donnees['nom'] ?? ''))) $erreurs[] = "Le nom du produit est obligatoire.";
    if (!isset($donnees['prix_unitaire_ht']) || !is_numeric($donnees['prix_unitaire_ht']) || $donnees['prix_unitaire_ht'] <= 0)
        $erreurs[] = "Le prix unitaire doit être un nombre positif.";
    if (empty($donnees['date_expiration']) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $donnees['date_expiration']))
        $erreurs[] = "La date d'expiration est invalide (format attendu : AAAA-MM-JJ).";
    if (!isset($donnees['quantite_stock']) || !is_numeric($donnees['quantite_stock']) || $donnees['quantite_stock'] < 0)
        $erreurs[] = "La quantité doit être un nombre positif ou nul.";
    return $erreurs;
}

function decrementer_stock($code_barre, $quantite) {
    $produits = charger_produits();
    foreach ($produits as &$p) {
        if ($p['code_barre'] === $code_barre) {
            $p['quantite_stock'] -= $quantite;
            break;
        }
    }
    sauvegarder_produits($produits);
}

function formater_prix($montant) {
    return number_format($montant, 0, ',', ' ') . ' ' . DEVISE;
}
