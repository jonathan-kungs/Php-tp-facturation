<?php
require_once __DIR__ . '/../config/config.php';

function charger_factures() {
    if (!file_exists(FACTURES_FILE)) return [];
    $json = file_get_contents(FACTURES_FILE);
    return json_decode($json, true) ?: [];
}

function sauvegarder_factures($factures) {
    file_put_contents(FACTURES_FILE, json_encode(array_values($factures), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function generer_id_facture() {
    $factures = charger_factures();
    $date = date('Ymd');
    $prefix = 'FAC-' . $date . '-';
    $max = 0;
    foreach ($factures as $f) {
        if (strpos($f['id_facture'], $prefix) === 0) {
            $num = (int)substr($f['id_facture'], strlen($prefix));
            if ($num > $max) $max = $num;
        }
    }
    return $prefix . str_pad($max + 1, 3, '0', STR_PAD_LEFT);
}

function creer_facture($articles, $caissier) {
    $total_ht = 0;
    foreach ($articles as $a) {
        $total_ht += $a['sous_total_ht'];
    }
    $tva = round($total_ht * TVA_TAUX);
    $total_ttc = $total_ht + $tva;

    $facture = [
        'id_facture' => generer_id_facture(),
        'date' => date('Y-m-d'),
        'heure' => date('H:i:s'),
        'caissier' => $caissier,
        'articles' => $articles,
        'total_ht' => $total_ht,
        'tva' => $tva,
        'total_ttc' => $total_ttc
    ];

    $factures = charger_factures();
    $factures[] = $facture;
    sauvegarder_factures($factures);

    require_once __DIR__ . '/fonctions-produits.php';
    foreach ($articles as $a) {
        decrementer_stock($a['code_barre'], $a['quantite']);
    }

    return $facture;
}

function trouver_facture($id_facture) {
    $factures = charger_factures();
    foreach ($factures as $f) {
        if ($f['id_facture'] === $id_facture) return $f;
    }
    return null;
}

function factures_du_jour() {
    $factures = charger_factures();
    $aujourd_hui = date('Y-m-d');
    return array_filter($factures, fn($f) => $f['date'] === $aujourd_hui);
}

function factures_du_mois($annee, $mois) {
    $factures = charger_factures();
    $prefix = sprintf('%04d-%02d', $annee, $mois);
    return array_filter($factures, fn($f) => strpos($f['date'], $prefix) === 0);
}

function total_factures($liste) {
    $total = 0;
    foreach ($liste as $f) $total += $f['total_ttc'];
    return $total;
}
