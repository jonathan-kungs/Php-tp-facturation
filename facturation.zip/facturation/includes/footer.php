</main>
<footer class="footer">
    <p><?= APP_NAME ?> v<?= APP_VERSION ?> &mdash; Université Protestante au Congo &mdash; <?= date('Y') ?></p>
</footer>
</body>
</html>
