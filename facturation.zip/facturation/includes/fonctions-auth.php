<?php
require_once __DIR__ . '/../config/config.php';

function charger_utilisateurs() {
    if (!file_exists(UTILISATEURS_FILE)) return [];
    $json = file_get_contents(UTILISATEURS_FILE);
    return json_decode($json, true) ?: [];
}

function sauvegarder_utilisateurs($utilisateurs) {
    file_put_contents(UTILISATEURS_FILE, json_encode($utilisateurs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function trouver_utilisateur($identifiant) {
    $utilisateurs = charger_utilisateurs();
    foreach ($utilisateurs as $u) {
        if ($u['identifiant'] === $identifiant) return $u;
    }
    return null;
}

function authentifier($identifiant, $mot_de_passe) {
    $u = trouver_utilisateur($identifiant);
    if (!$u) return false;
    if (!$u['actif']) return false;
    if (!password_verify($mot_de_passe, $u['mot_de_passe'])) return false;
    return $u;
}

function utilisateur_connecte() {
    if (session_status() === PHP_SESSION_NONE) {
        session_name(SESSION_NAME);
        session_start();
    }
    return isset($_SESSION['utilisateur']) ? $_SESSION['utilisateur'] : null;
}

function exiger_connexion() {
    $u = utilisateur_connecte();
    if (!$u) {
        header('Location: ' . chemin_relatif('auth/login.php'));
        exit;
    }
    return $u;
}

function exiger_role($roles_autorises) {
    $u = exiger_connexion();
    if (!is_array($roles_autorises)) $roles_autorises = [$roles_autorises];
    if (!in_array($u['role'], $roles_autorises)) {
        $_SESSION['erreur_acces'] = "Accès refusé : vous n'avez pas les droits nécessaires.";
        header('Location: ' . chemin_relatif('index.php'));
        exit;
    }
    return $u;
}

function ajouter_utilisateur($identifiant, $mot_de_passe, $role, $nom_complet) {
    $utilisateurs = charger_utilisateurs();
    foreach ($utilisateurs as $u) {
        if ($u['identifiant'] === $identifiant) return false;
    }
    $hash = password_hash($mot_de_passe, PASSWORD_BCRYPT);
    $utilisateurs[] = [
        'identifiant' => $identifiant,
        'mot_de_passe' => $hash,
        'role' => $role,
        'nom_complet' => $nom_complet,
        'date_creation' => date('Y-m-d'),
        'actif' => true
    ];
    sauvegarder_utilisateurs($utilisateurs);
    return true;
}

function supprimer_utilisateur($identifiant) {
    $utilisateurs = charger_utilisateurs();
    $nouveaux = array_filter($utilisateurs, fn($u) => $u['identifiant'] !== $identifiant);
    sauvegarder_utilisateurs(array_values($nouveaux));
    return true;
}

function basculer_statut_utilisateur($identifiant) {
    $utilisateurs = charger_utilisateurs();
    foreach ($utilisateurs as &$u) {
        if ($u['identifiant'] === $identifiant) {
            $u['actif'] = !$u['actif'];
            break;
        }
    }
    sauvegarder_utilisateurs($utilisateurs);
}

function chemin_relatif($cible) {
    $depth = substr_count($_SERVER['PHP_SELF'], '/') - 1;
    return str_repeat('../', $depth) . $cible;
}

function libelle_role($role) {
    $labels = [
        'super_admin' => 'Super Administrateur',
        'manager' => 'Manager',
        'caissier' => 'Caissier'
    ];
    return $labels[$role] ?? $role;
}
