<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../auth/session.php';
require_once __DIR__ . '/../includes/fonctions-auth.php';

$utilisateur_courant = utilisateur_connecte();
$role = $utilisateur_courant['role'] ?? '';

$racine = chemin_relatif('');
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($titre_page) ? htmlspecialchars($titre_page) . ' — ' : '' ?><?= APP_NAME ?></title>
    <link rel="stylesheet" href="<?= $racine ?>assets/css/style.css">
</head>
<body>
<nav class="navbar">
    <div class="nav-brand">
        <span class="nav-logo">🏪</span>
        <span><?= APP_NAME ?></span>
    </div>
    <?php if ($utilisateur_courant): ?>
    <div class="nav-links">
        <?php if (in_array($role, ['caissier', 'manager', 'super_admin'])): ?>
        <a href="<?= $racine ?>modules/facturation/nouvelle-facture.php" class="nav-link">
            🧾 Nouvelle Facture
        </a>
        <?php endif; ?>

        <?php if (in_array($role, ['manager', 'super_admin'])): ?>
        <a href="<?= $racine ?>modules/produits/liste.php" class="nav-link">
            📦 Produits
        </a>
        <a href="<?= $racine ?>rapports/rapport-journalier.php" class="nav-link">
            📊 Rapports
        </a>
        <?php endif; ?>

        <?php if ($role === 'super_admin'): ?>
        <a href="<?= $racine ?>modules/admin/gestion-comptes.php" class="nav-link">
            👥 Comptes
        </a>
        <?php endif; ?>
    </div>
    <div class="nav-user">
        <span class="user-badge user-badge-<?= $role ?>">
            <?= libelle_role($role) ?>
        </span>
        <span class="user-name"><?= htmlspecialchars($utilisateur_courant['nom_complet']) ?></span>
        <a href="<?= $racine ?>auth/logout.php" class="btn btn-sm btn-outline">Déconnexion</a>
    </div>
    <?php endif; ?>
</nav>

<?php if (!empty($_SESSION['erreur_acces'])): ?>
<div class="container">
    <div class="alert alert-danger"><?= htmlspecialchars($_SESSION['erreur_acces']) ?></div>
</div>
<?php unset($_SESSION['erreur_acces']); endif; ?>

<?php if (!empty($_SESSION['message_succes'])): ?>
<div class="container">
    <div class="alert alert-success"><?= htmlspecialchars($_SESSION['message_succes']) ?></div>
</div>
<?php unset($_SESSION['message_succes']); endif; ?>

<main class="container">
