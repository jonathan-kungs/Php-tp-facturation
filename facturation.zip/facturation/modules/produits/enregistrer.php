<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-produits.php';

$utilisateur = exiger_role(['manager', 'super_admin']);
$titre_page = 'Enregistrement Produit';

$erreurs = [];
$succes = '';
$produit_existant = null;
$code_barre_recu = '';
$donnees = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'verifier_code') {
        $code_barre_recu = trim($_POST['code_barre'] ?? '');
        if (!empty($code_barre_recu)) {
            $produit_existant = trouver_produit_par_code($code_barre_recu);
        }
    } elseif ($action === 'enregistrer') {
        $donnees = [
            'code_barre' => trim($_POST['code_barre'] ?? ''),
            'nom' => trim($_POST['nom'] ?? ''),
            'prix_unitaire_ht' => $_POST['prix_unitaire_ht'] ?? '',
            'date_expiration' => trim($_POST['date_expiration'] ?? ''),
            'quantite_stock' => $_POST['quantite_stock'] ?? '',
        ];
        $erreurs = enregistrer_produit($donnees);
        if (empty($erreurs)) {
            $_SESSION['message_succes'] = "Produit enregistré avec succès.";
            header('Location: liste.php');
            exit;
        }
    }
}

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h2>📦 Enregistrement d'un Produit</h2>
    <p class="text-muted">Scannez le code-barres ou saisissez-le manuellement pour enregistrer un nouveau produit.</p>
</div>

<?php if (!empty($erreurs)): ?>
<div class="alert alert-danger">
    <strong>Erreurs de validation :</strong>
    <ul><?php foreach ($erreurs as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3>Étape 1 – Lire le code-barres</h3>
    </div>
    <div class="card-body">
        <button type="button" class="btn btn-primary" onclick="Scanner.start()">
            📷 Activer la caméra
        </button>
        <button type="button" class="btn btn-outline" onclick="activerSaisieManuelle('code_barre_input')">
            ⌨ Saisie manuelle
        </button>

        <div id="scanner-container" style="display:none; margin-top:1rem; max-width:500px;">
            <p class="text-muted">Pointez la caméra vers le code-barres...</p>
        </div>

        <form method="POST" action="" style="margin-top:1.5rem;" id="form-verif">
            <input type="hidden" name="action" value="verifier_code">
            <div class="form-row">
                <div class="form-group">
                    <label for="code_barre_input">Code-barres</label>
                    <input type="text" id="code_barre_input" name="code_barre"
                           value="<?= htmlspecialchars($code_barre_recu ?: ($donnees['code_barre'] ?? '')) ?>"
                           placeholder="Ex : 3017620422003" readonly>
                </div>
                <div class="form-group" style="align-self:flex-end;">
                    <button type="submit" class="btn btn-secondary">🔍 Vérifier</button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php if ($produit_existant): ?>
<div class="alert alert-info">
    <strong>Produit déjà enregistré :</strong> <?= htmlspecialchars($produit_existant['nom']) ?>
    — <?= formater_prix($produit_existant['prix_unitaire_ht']) ?> HT
    — Stock : <?= $produit_existant['quantite_stock'] ?> unité(s)
    <br><small>Vous pouvez modifier les informations ci-dessous.</small>
</div>
<?php endif; ?>

<?php if (!empty($code_barre_recu) || !empty($donnees)): ?>
<div class="card" style="margin-top:1.5rem;">
    <div class="card-header">
        <h3>Étape 2 – Informations du produit</h3>
    </div>
    <div class="card-body">
        <form method="POST" action="">
            <input type="hidden" name="action" value="enregistrer">
            <input type="hidden" name="code_barre" value="<?= htmlspecialchars($donnees['code_barre'] ?? $code_barre_recu) ?>">

            <div class="form-grid">
                <div class="form-group">
                    <label>Code-barres</label>
                    <input type="text" value="<?= htmlspecialchars($donnees['code_barre'] ?? $code_barre_recu) ?>" readonly class="input-readonly">
                </div>
                <div class="form-group">
                    <label for="nom">Nom du produit *</label>
                    <input type="text" id="nom" name="nom"
                           value="<?= htmlspecialchars($donnees['nom'] ?? $produit_existant['nom'] ?? '') ?>"
                           placeholder="Ex : Huile de palme 1L" required>
                </div>
                <div class="form-group">
                    <label for="prix_unitaire_ht">Prix unitaire HT (<?= DEVISE ?>) *</label>
                    <input type="number" id="prix_unitaire_ht" name="prix_unitaire_ht"
                           value="<?= htmlspecialchars($donnees['prix_unitaire_ht'] ?? $produit_existant['prix_unitaire_ht'] ?? '') ?>"
                           min="0" step="1" placeholder="Ex : 1200" required>
                </div>
                <div class="form-group">
                    <label for="date_expiration">Date d'expiration *</label>
                    <input type="date" id="date_expiration" name="date_expiration"
                           value="<?= htmlspecialchars($donnees['date_expiration'] ?? $produit_existant['date_expiration'] ?? '') ?>"
                           required>
                </div>
                <div class="form-group">
                    <label for="quantite_stock">Quantité en stock *</label>
                    <input type="number" id="quantite_stock" name="quantite_stock"
                           value="<?= htmlspecialchars($donnees['quantite_stock'] ?? $produit_existant['quantite_stock'] ?? '') ?>"
                           min="0" step="1" placeholder="Ex : 50" required>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 Enregistrer le produit</button>
                <a href="liste.php" class="btn btn-outline">Annuler</a>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<script src="../../assets/js/scanner.js"></script>
<script>
Scanner.init('scanner-container', 'code_barre_input', function(code) {
    document.getElementById('code_barre_input').value = code;
    document.getElementById('form-verif').submit();
});
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
