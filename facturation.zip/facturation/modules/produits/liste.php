<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-produits.php';

$utilisateur = exiger_role(['manager', 'super_admin']);
$titre_page = 'Liste des Produits';

$produits = charger_produits();
$recherche = trim($_GET['q'] ?? '');

if ($recherche) {
    $produits = array_filter($produits, function($p) use ($recherche) {
        return stripos($p['nom'], $recherche) !== false
            || stripos($p['code_barre'], $recherche) !== false;
    });
}

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h2>📦 Liste des Produits</h2>
    <a href="enregistrer.php" class="btn btn-primary">➕ Nouveau produit</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="" class="search-form">
            <input type="text" name="q" value="<?= htmlspecialchars($recherche) ?>"
                   placeholder="Rechercher par nom ou code-barres..." class="search-input">
            <button type="submit" class="btn btn-secondary">🔍 Rechercher</button>
            <?php if ($recherche): ?>
            <a href="liste.php" class="btn btn-outline">✕ Effacer</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php if (empty($produits)): ?>
<div class="empty-state">
    <div class="empty-icon">📦</div>
    <h3>Aucun produit enregistré</h3>
    <p>Commencez par enregistrer votre premier produit.</p>
    <a href="enregistrer.php" class="btn btn-primary">➕ Enregistrer un produit</a>
</div>
<?php else: ?>
<div class="card" style="margin-top:1rem;">
    <div class="card-body" style="padding:0;">
        <table class="table">
            <thead>
                <tr>
                    <th>Code-barres</th>
                    <th>Nom</th>
                    <th>Prix HT</th>
                    <th>TVA (18%)</th>
                    <th>Prix TTC</th>
                    <th>Stock</th>
                    <th>Expiration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produits as $p): ?>
                <?php
                    $stock_faible = $p['quantite_stock'] <= 5;
                    $expire_bientot = strtotime($p['date_expiration']) < strtotime('+30 days');
                    $tva = round($p['prix_unitaire_ht'] * TVA_TAUX);
                    $ttc = $p['prix_unitaire_ht'] + $tva;
                ?>
                <tr class="<?= $stock_faible ? 'row-warning' : '' ?>">
                    <td><code><?= htmlspecialchars($p['code_barre']) ?></code></td>
                    <td><?= htmlspecialchars($p['nom']) ?></td>
                    <td class="montant"><?= formater_prix($p['prix_unitaire_ht']) ?></td>
                    <td class="montant"><?= formater_prix($tva) ?></td>
                    <td class="montant"><strong><?= formater_prix($ttc) ?></strong></td>
                    <td>
                        <span class="badge <?= $stock_faible ? 'badge-danger' : 'badge-success' ?>">
                            <?= $p['quantite_stock'] ?> unité(s)
                        </span>
                    </td>
                    <td class="<?= $expire_bientot ? 'text-warning' : '' ?>">
                        <?= htmlspecialchars($p['date_expiration']) ?>
                    </td>
                    <td>
                        <a href="enregistrer.php" class="btn btn-sm btn-outline"
                           onclick="sessionStorage.setItem('prefill_code', '<?= htmlspecialchars($p['code_barre']) ?>')">
                            ✏ Modifier
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="text-muted" style="margin-top:.5rem;">
    <?= count($produits) ?> produit(s) affiché(s)
</p>
<?php endif; ?>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
