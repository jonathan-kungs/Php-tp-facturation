<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-produits.php';

exiger_connexion();
header('Content-Type: application/json');

$code_barre = trim($_GET['code'] ?? '');
if (empty($code_barre)) {
    echo json_encode(['succes' => false, 'message' => 'Code-barres manquant.']);
    exit;
}

$produit = trouver_produit_par_code($code_barre);
if (!$produit) {
    echo json_encode(['succes' => false, 'message' => 'Produit inconnu. Veuillez le faire enregistrer par un Manager.']);
    exit;
}

$tva = round($produit['prix_unitaire_ht'] * TVA_TAUX);
$produit['prix_ttc'] = $produit['prix_unitaire_ht'] + $tva;
echo json_encode(['succes' => true, 'produit' => $produit]);
