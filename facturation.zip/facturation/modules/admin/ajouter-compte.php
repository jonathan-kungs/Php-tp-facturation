<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';

$utilisateur = exiger_role('super_admin');
$titre_page = 'Ajouter un compte';

$erreurs = [];
$donnees = ['identifiant' => '', 'nom_complet' => '', 'role' => 'caissier'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $donnees['identifiant'] = trim($_POST['identifiant'] ?? '');
    $donnees['nom_complet'] = trim($_POST['nom_complet'] ?? '');
    $donnees['role'] = $_POST['role'] ?? 'caissier';
    $mot_de_passe = $_POST['mot_de_passe'] ?? '';
    $confirmer = $_POST['confirmer_mdp'] ?? '';

    if (empty($donnees['identifiant'])) $erreurs[] = "L'identifiant est obligatoire.";
    elseif (!preg_match('/^[a-z0-9._-]+$/', $donnees['identifiant'])) $erreurs[] = "Identifiant invalide (lettres minuscules, chiffres, points, tirets uniquement).";
    if (empty($donnees['nom_complet'])) $erreurs[] = "Le nom complet est obligatoire.";
    if (empty($mot_de_passe)) $erreurs[] = "Le mot de passe est obligatoire.";
    elseif (strlen($mot_de_passe) < 6) $erreurs[] = "Le mot de passe doit comporter au moins 6 caractères.";
    elseif ($mot_de_passe !== $confirmer) $erreurs[] = "Les mots de passe ne correspondent pas.";
    if (!in_array($donnees['role'], ['caissier', 'manager', 'super_admin'])) $erreurs[] = "Rôle invalide.";

    if (empty($erreurs)) {
        $ok = ajouter_utilisateur($donnees['identifiant'], $mot_de_passe, $donnees['role'], $donnees['nom_complet']);
        if (!$ok) {
            $erreurs[] = "Cet identifiant est déjà utilisé.";
        } else {
            $_SESSION['message_succes'] = "Compte créé avec succès.";
            header('Location: gestion-comptes.php');
            exit;
        }
    }
}

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h2>👤 Ajouter un compte utilisateur</h2>
    <a href="gestion-comptes.php" class="btn btn-outline">← Retour</a>
</div>

<?php if (!empty($erreurs)): ?>
<div class="alert alert-danger">
    <strong>Erreurs :</strong>
    <ul><?php foreach ($erreurs as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
</div>
<?php endif; ?>

<div class="card" style="max-width:600px;">
    <div class="card-header"><h3>Informations du compte</h3></div>
    <div class="card-body">
        <form method="POST" action="">
            <div class="form-group">
                <label for="identifiant">Identifiant *</label>
                <input type="text" id="identifiant" name="identifiant"
                       value="<?= htmlspecialchars($donnees['identifiant']) ?>"
                       placeholder="Ex : jean.dupont" pattern="[a-z0-9._-]+" required>
                <small class="text-muted">Lettres minuscules, chiffres, points et tirets uniquement.</small>
            </div>
            <div class="form-group">
                <label for="nom_complet">Nom complet *</label>
                <input type="text" id="nom_complet" name="nom_complet"
                       value="<?= htmlspecialchars($donnees['nom_complet']) ?>"
                       placeholder="Ex : Jean Dupont" required>
            </div>
            <div class="form-group">
                <label for="role">Rôle *</label>
                <select id="role" name="role" required>
                    <option value="caissier" <?= $donnees['role'] === 'caissier' ? 'selected' : '' ?>>Caissier</option>
                    <option value="manager" <?= $donnees['role'] === 'manager' ? 'selected' : '' ?>>Manager</option>
                    <option value="super_admin" <?= $donnees['role'] === 'super_admin' ? 'selected' : '' ?>>Super Administrateur</option>
                </select>
            </div>
            <div class="form-group">
                <label for="mot_de_passe">Mot de passe *</label>
                <input type="password" id="mot_de_passe" name="mot_de_passe"
                       placeholder="Minimum 6 caractères" required minlength="6">
            </div>
            <div class="form-group">
                <label for="confirmer_mdp">Confirmer le mot de passe *</label>
                <input type="password" id="confirmer_mdp" name="confirmer_mdp"
                       placeholder="Répétez le mot de passe" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">💾 Créer le compte</button>
                <a href="gestion-comptes.php" class="btn btn-outline">Annuler</a>
            </div>
        </form>
    </div>
</div>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
