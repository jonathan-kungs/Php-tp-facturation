<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';

$utilisateur = exiger_role('super_admin');
$titre_page = 'Gestion des Comptes';

$utilisateurs = charger_utilisateurs();
include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h2>👥 Gestion des Comptes Utilisateurs</h2>
    <a href="ajouter-compte.php" class="btn btn-primary">➕ Nouveau compte</a>
</div>

<?php if (count($utilisateurs) === 0): ?>
<div class="empty-state">
    <div class="empty-icon">👥</div>
    <h3>Aucun compte trouvé</h3>
</div>
<?php else: ?>
<div class="card">
    <div class="card-body" style="padding:0;">
        <table class="table">
            <thead>
                <tr>
                    <th>Identifiant</th>
                    <th>Nom complet</th>
                    <th>Rôle</th>
                    <th>Date de création</th>
                    <th>Statut</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($utilisateurs as $u): ?>
                <tr>
                    <td><code><?= htmlspecialchars($u['identifiant']) ?></code></td>
                    <td><?= htmlspecialchars($u['nom_complet']) ?></td>
                    <td>
                        <span class="badge user-badge-<?= $u['role'] ?>">
                            <?= libelle_role($u['role']) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($u['date_creation']) ?></td>
                    <td>
                        <span class="badge <?= $u['actif'] ? 'badge-success' : 'badge-danger' ?>">
                            <?= $u['actif'] ? 'Actif' : 'Désactivé' ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($u['identifiant'] !== $utilisateur['identifiant']): ?>
                        <form method="POST" action="supprimer-compte.php" style="display:inline;"
                              onsubmit="return confirm('Supprimer le compte <?= htmlspecialchars($u['identifiant']) ?> ?')">
                            <input type="hidden" name="identifiant" value="<?= htmlspecialchars($u['identifiant']) ?>">
                            <input type="hidden" name="action" value="supprimer">
                            <button type="submit" class="btn btn-sm btn-danger-outline">🗑 Supprimer</button>
                        </form>
                        <form method="POST" action="supprimer-compte.php" style="display:inline;">
                            <input type="hidden" name="identifiant" value="<?= htmlspecialchars($u['identifiant']) ?>">
                            <input type="hidden" name="action" value="basculer">
                            <button type="submit" class="btn btn-sm btn-outline">
                                <?= $u['actif'] ? '⏸ Désactiver' : '▶ Activer' ?>
                            </button>
                        </form>
                        <?php else: ?>
                        <span class="text-muted">(compte actuel)</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
