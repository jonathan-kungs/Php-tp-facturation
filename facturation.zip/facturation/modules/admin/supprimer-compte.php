<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';

$utilisateur = exiger_role('super_admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $action = $_POST['action'] ?? '';

    if (empty($identifiant) || $identifiant === $utilisateur['identifiant']) {
        $_SESSION['erreur_acces'] = "Action non autorisée.";
    } elseif ($action === 'supprimer') {
        supprimer_utilisateur($identifiant);
        $_SESSION['message_succes'] = "Compte supprimé.";
    } elseif ($action === 'basculer') {
        basculer_statut_utilisateur($identifiant);
        $_SESSION['message_succes'] = "Statut du compte mis à jour.";
    }
}

header('Location: gestion-comptes.php');
exit;
