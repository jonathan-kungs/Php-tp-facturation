<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-factures.php';

$utilisateur = exiger_connexion();

if (empty($_SESSION['panier'])) {
    header('Location: nouvelle-facture.php');
    exit;
}

$facture = creer_facture($_SESSION['panier'], $utilisateur['identifiant']);
$_SESSION['panier'] = [];
$_SESSION['derniere_facture'] = $facture['id_facture'];

header('Location: afficher-facture.php?id=' . urlencode($facture['id_facture']));
exit;
