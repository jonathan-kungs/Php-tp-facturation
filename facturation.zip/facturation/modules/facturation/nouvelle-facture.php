<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-produits.php';

$utilisateur = exiger_connexion();
$titre_page = 'Nouvelle Facture';

if (!isset($_SESSION['panier'])) $_SESSION['panier'] = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'ajouter_article') {
        $code_barre = trim($_POST['code_barre'] ?? '');
        $quantite = (int)($_POST['quantite'] ?? 1);
        $erreur_article = '';

        if (empty($code_barre)) {
            $erreur_article = "Veuillez scanner ou saisir un code-barres.";
        } elseif ($quantite <= 0) {
            $erreur_article = "La quantité doit être supérieure à zéro.";
        } else {
            $produit = trouver_produit_par_code($code_barre);
            if (!$produit) {
                $erreur_article = "Produit inconnu (code : $code_barre). Demandez à un Manager de l'enregistrer.";
            } elseif ($quantite > $produit['quantite_stock']) {
                $erreur_article = "Stock insuffisant ! Stock disponible : {$produit['quantite_stock']} unité(s).";
            } else {
                $deja = false;
                foreach ($_SESSION['panier'] as &$item) {
                    if ($item['code_barre'] === $code_barre) {
                        $nouvelle_qte = $item['quantite'] + $quantite;
                        if ($nouvelle_qte > $produit['quantite_stock']) {
                            $erreur_article = "Quantité totale dépasse le stock disponible ({$produit['quantite_stock']} unité(s)).";
                        } else {
                            $item['quantite'] = $nouvelle_qte;
                            $item['sous_total_ht'] = $item['prix_unitaire_ht'] * $nouvelle_qte;
                        }
                        $deja = true;
                        break;
                    }
                }
                if (!$deja) {
                    $_SESSION['panier'][] = [
                        'code_barre' => $produit['code_barre'],
                        'nom' => $produit['nom'],
                        'prix_unitaire_ht' => $produit['prix_unitaire_ht'],
                        'quantite' => $quantite,
                        'sous_total_ht' => $produit['prix_unitaire_ht'] * $quantite
                    ];
                }
            }
        }
        $_SESSION['erreur_article'] = $erreur_article ?? '';
    }

    if ($action === 'retirer_article') {
        $idx = (int)($_POST['index'] ?? -1);
        if (isset($_SESSION['panier'][$idx])) {
            array_splice($_SESSION['panier'], $idx, 1);
        }
    }

    if ($action === 'vider_panier') {
        $_SESSION['panier'] = [];
    }

    header('Location: nouvelle-facture.php');
    exit;
}

$panier = $_SESSION['panier'];
$total_ht = array_sum(array_column($panier, 'sous_total_ht'));
$tva = round($total_ht * TVA_TAUX);
$total_ttc = $total_ht + $tva;

$erreur_article = $_SESSION['erreur_article'] ?? '';
unset($_SESSION['erreur_article']);

include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header">
    <h2>🧾 Nouvelle Facture</h2>
    <div>
        <span class="badge badge-info"><?= count($panier) ?> article(s)</span>
    </div>
</div>

<div class="facture-layout">
    <div class="facture-scanner">
        <div class="card">
            <div class="card-header"><h3>Scanner un article</h3></div>
            <div class="card-body">
                <div class="scan-buttons">
                    <button type="button" class="btn btn-primary" onclick="demarrerScan()">
                        📷 Activer la caméra
                    </button>
                    <button type="button" class="btn btn-outline" onclick="activerSaisieManuelle('code_scan')">
                        ⌨ Saisie manuelle
                    </button>
                </div>

                <div id="scanner-container" style="display:none; margin:1rem 0; max-width:100%;">
                    <p class="text-muted">Pointez la caméra vers le code-barres du produit...</p>
                </div>

                <?php if ($erreur_article): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($erreur_article) ?></div>
                <?php endif; ?>

                <div id="produit-info" class="produit-info-box" style="display:none;">
                    <strong id="produit-nom"></strong><br>
                    <span>Prix HT : <strong id="produit-prix"></strong></span><br>
                    <span>Stock : <strong id="produit-stock"></strong></span>
                </div>

                <form method="POST" action="" id="form-ajout" style="margin-top:1rem;">
                    <input type="hidden" name="action" value="ajouter_article">
                    <div class="form-group">
                        <label>Code-barres</label>
                        <input type="text" id="code_scan" name="code_barre"
                               placeholder="Scanner ou saisir le code..." readonly
                               oninput="rechercherProduit(this.value)">
                    </div>
                    <div class="form-group">
                        <label for="quantite">Quantité</label>
                        <input type="number" id="quantite" name="quantite" value="1" min="1" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full">➕ Ajouter à la facture</button>
                </form>
            </div>
        </div>
    </div>

    <div class="facture-recap">
        <div class="card">
            <div class="card-header">
                <h3>Récapitulatif de la facture</h3>
            </div>
            <div class="card-body" style="padding:0;">
                <?php if (empty($panier)): ?>
                <div class="empty-state" style="padding:2rem;">
                    <p>Aucun article ajouté.<br>Scannez un produit pour commencer.</p>
                </div>
                <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Désignation</th>
                            <th>Prix HT</th>
                            <th>Qté</th>
                            <th>Sous-total HT</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($panier as $i => $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['nom']) ?></td>
                            <td class="montant"><?= formater_prix($item['prix_unitaire_ht']) ?></td>
                            <td><?= $item['quantite'] ?></td>
                            <td class="montant"><?= formater_prix($item['sous_total_ht']) ?></td>
                            <td>
                                <form method="POST" action="" style="display:inline;">
                                    <input type="hidden" name="action" value="retirer_article">
                                    <input type="hidden" name="index" value="<?= $i ?>">
                                    <button type="submit" class="btn btn-sm btn-danger-outline" title="Retirer">✕</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3" class="text-right"><strong>Total HT</strong></td>
                            <td class="montant"><strong><?= formater_prix($total_ht) ?></strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="3" class="text-right">TVA (<?= (int)(TVA_TAUX*100) ?>%)</td>
                            <td class="montant"><?= formater_prix($tva) ?></td>
                            <td></td>
                        </tr>
                        <tr class="total-row">
                            <td colspan="3" class="text-right"><strong>Net à payer</strong></td>
                            <td class="montant total-final"><strong><?= formater_prix($total_ttc) ?></strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
                <?php endif; ?>
            </div>

            <?php if (!empty($panier)): ?>
            <div class="card-footer">
                <a href="calcul.php" class="btn btn-success btn-large">✅ Valider et émettre la facture</a>
                <form method="POST" action="" style="display:inline;">
                    <input type="hidden" name="action" value="vider_panier">
                    <button type="submit" class="btn btn-outline"
                            onclick="return confirm('Vider le panier ?')">🗑 Vider</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="../../assets/js/scanner.js"></script>
<script>
const LIRE_URL = '../../modules/produits/lire.php';

Scanner.init('scanner-container', 'code_scan', function(code) {
    document.getElementById('code_scan').value = code;
    rechercherProduit(code);
});

function demarrerScan() {
    Scanner.start();
}

function rechercherProduit(code) {
    if (!code || code.length < 4) {
        document.getElementById('produit-info').style.display = 'none';
        return;
    }
    fetch(LIRE_URL + '?code=' + encodeURIComponent(code))
        .then(r => r.json())
        .then(data => {
            const box = document.getElementById('produit-info');
            if (data.succes) {
                const p = data.produit;
                document.getElementById('produit-nom').textContent = p.nom;
                document.getElementById('produit-prix').textContent = p.prix_unitaire_ht.toLocaleString('fr-CD') + ' CDF';
                document.getElementById('produit-stock').textContent = p.quantite_stock + ' unité(s)';
                box.style.display = 'block';
                box.className = 'produit-info-box produit-found';
            } else {
                box.innerHTML = '<span class="text-danger">⚠ ' + data.message + '</span>';
                box.style.display = 'block';
                box.className = 'produit-info-box produit-not-found';
            }
        });
}
</script>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
