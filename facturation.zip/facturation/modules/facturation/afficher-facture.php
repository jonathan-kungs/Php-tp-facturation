<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../auth/session.php';
require_once __DIR__ . '/../../includes/fonctions-auth.php';
require_once __DIR__ . '/../../includes/fonctions-factures.php';
require_once __DIR__ . '/../../includes/fonctions-produits.php';

$utilisateur = exiger_connexion();
$id_facture = trim($_GET['id'] ?? '');
$facture = trouver_facture($id_facture);

if (!$facture) {
    header('Location: ../../index.php');
    exit;
}

$titre_page = 'Facture ' . $facture['id_facture'];
include __DIR__ . '/../../includes/header.php';
?>

<div class="page-header no-print">
    <h2>🧾 Facture générée</h2>
    <div>
        <button onclick="window.print()" class="btn btn-primary">🖨 Imprimer</button>
        <a href="nouvelle-facture.php" class="btn btn-outline">➕ Nouvelle facture</a>
        <a href="../../index.php" class="btn btn-outline">🏠 Accueil</a>
    </div>
</div>

<div class="facture-document" id="facture-print">
    <div class="facture-entete">
        <div class="facture-societe">
            <h2>🏪 <?= APP_NAME ?></h2>
            <p>Université Protestante au Congo</p>
        </div>
        <div class="facture-meta">
            <div class="facture-id"><?= htmlspecialchars($facture['id_facture']) ?></div>
            <div>Date : <strong><?= htmlspecialchars($facture['date']) ?></strong></div>
            <div>Heure : <strong><?= htmlspecialchars($facture['heure']) ?></strong></div>
            <div>Caissier : <strong><?= htmlspecialchars($facture['caissier']) ?></strong></div>
        </div>
    </div>

    <div class="facture-separator"></div>

    <table class="table facture-table">
        <thead>
            <tr>
                <th>Désignation</th>
                <th class="text-right">Prix unit. HT</th>
                <th class="text-center">Qté</th>
                <th class="text-right">Sous-total HT</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($facture['articles'] as $a): ?>
            <tr>
                <td><?= htmlspecialchars($a['nom']) ?></td>
                <td class="montant"><?= formater_prix($a['prix_unitaire_ht']) ?></td>
                <td class="text-center"><?= $a['quantite'] ?></td>
                <td class="montant"><?= formater_prix($a['sous_total_ht']) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-right">Total HT</td>
                <td class="montant"><?= formater_prix($facture['total_ht']) ?></td>
            </tr>
            <tr>
                <td colspan="3" class="text-right">TVA (<?= (int)(TVA_TAUX*100) ?>%)</td>
                <td class="montant"><?= formater_prix($facture['tva']) ?></td>
            </tr>
            <tr class="total-row">
                <td colspan="3" class="text-right"><strong>Net à payer</strong></td>
                <td class="montant total-final"><strong><?= formater_prix($facture['total_ttc']) ?></strong></td>
            </tr>
        </tfoot>
    </table>

    <div class="facture-pied">
        <p>Merci de votre achat !</p>
        <p class="text-muted"><small>Document généré automatiquement — TVA incluse au taux de <?= (int)(TVA_TAUX*100) ?>%</small></p>
    </div>
</div>

<style>
@media print {
    .no-print { display: none !important; }
    .navbar, .footer { display: none !important; }
    body { background: white; }
    .facture-document { box-shadow: none; border: none; }
}
</style>

<?php include __DIR__ . '/../../includes/footer.php'; ?>
