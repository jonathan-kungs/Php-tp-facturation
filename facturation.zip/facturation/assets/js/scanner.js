/**
 * Scanner de codes-barres via la caméra
 * Utilise la bibliothèque QuaggaJS
 */

const Scanner = {
    active: false,
    onDetect: null,

    init: function(containerId, inputId, onDetectCallback) {
        this.containerId = containerId;
        this.inputId = inputId;
        this.onDetect = onDetectCallback || function(code) {
            document.getElementById(inputId).value = code;
        };
    },

    start: function() {
        const container = document.getElementById(this.containerId);
        if (!container) return;

        container.style.display = 'block';
        this.active = true;

        if (typeof Quagga === 'undefined') {
            this._chargerQuagga(() => this._demarrerQuagga(container));
        } else {
            this._demarrerQuagga(container);
        }
    },

    _chargerQuagga: function(callback) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/quagga@0.12.1/dist/quagga.min.js';
        script.onload = callback;
        script.onerror = () => {
            alert("Impossible de charger le scanner. Vérifiez votre connexion internet.");
        };
        document.head.appendChild(script);
    },

    _demarrerQuagga: function(container) {
        const viewportId = this.containerId + '-viewport';
        let viewport = document.getElementById(viewportId);
        if (!viewport) {
            viewport = document.createElement('div');
            viewport.id = viewportId;
            container.appendChild(viewport);
        }

        Quagga.init({
            inputStream: {
                name: "Live",
                type: "LiveStream",
                target: viewport,
                constraints: {
                    width: { min: 640 },
                    height: { min: 480 },
                    facingMode: "environment"
                }
            },
            locator: {
                patchSize: "medium",
                halfSample: true
            },
            numOfWorkers: navigator.hardwareConcurrency || 2,
            frequency: 10,
            decoder: {
                readers: [
                    "ean_reader",
                    "ean_8_reader",
                    "code_128_reader",
                    "code_39_reader",
                    "upc_reader",
                    "upc_e_reader"
                ]
            },
            locate: true
        }, (err) => {
            if (err) {
                console.error("Erreur Quagga:", err);
                this._afficherErreurCamera(container, err);
                return;
            }
            Quagga.start();
            this._afficherBoutonStop(container);
        });

        Quagga.onDetected((result) => {
            const code = result.codeResult.code;
            if (code && this.active) {
                this.active = false;
                Quagga.stop();
                this._jouerBip();
                container.style.display = 'none';

                if (this.onDetect) this.onDetect(code);
            }
        });

        Quagga.onProcessed((result) => {
            const drawingCtx = Quagga.canvas.ctx.overlay;
            const drawingCanvas = Quagga.canvas.dom.overlay;
            if (!drawingCtx || !drawingCanvas) return;

            drawingCtx.clearRect(0, 0, drawingCanvas.width, drawingCanvas.height);

            if (result && result.boxes) {
                result.boxes.filter(b => b !== result.box).forEach(box => {
                    Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: 'green', lineWidth: 2 });
                });
            }
            if (result && result.box) {
                Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: '#00F', lineWidth: 2 });
            }
        });
    },

    stop: function() {
        if (typeof Quagga !== 'undefined') {
            try { Quagga.stop(); } catch(e) {}
        }
        this.active = false;
        const container = document.getElementById(this.containerId);
        if (container) container.style.display = 'none';
    },

    _afficherBoutonStop: function(container) {
        let btn = container.querySelector('.btn-stop-scan');
        if (!btn) {
            btn = document.createElement('button');
            btn.className = 'btn btn-danger btn-stop-scan';
            btn.textContent = '⏹ Arrêter le scan';
            btn.type = 'button';
            btn.onclick = () => this.stop();
            container.appendChild(btn);
        }
    },

    _afficherErreurCamera: function(container, err) {
        container.innerHTML = `
            <div class="alert alert-danger">
                <strong>Erreur caméra :</strong> ${err.message || err}<br>
                <small>Assurez-vous d'autoriser l'accès à la caméra dans votre navigateur et d'utiliser HTTPS ou localhost.</small>
            </div>
            <button type="button" class="btn btn-outline" onclick="document.getElementById('${this.containerId}').style.display='none'">Fermer</button>
        `;
    },

    _jouerBip: function() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const oscillator = ctx.createOscillator();
            const gainNode = ctx.createGain();
            oscillator.connect(gainNode);
            gainNode.connect(ctx.destination);
            oscillator.type = 'square';
            oscillator.frequency.value = 800;
            gainNode.gain.setValueAtTime(0.3, ctx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
            oscillator.start(ctx.currentTime);
            oscillator.stop(ctx.currentTime + 0.1);
        } catch(e) {}
    }
};

/* Saisie manuelle du code-barres en cas de problème caméra */
function activerSaisieManuelle(inputId) {
    const input = document.getElementById(inputId);
    if (input) {
        input.removeAttribute('readonly');
        input.focus();
        input.placeholder = "Tapez ou scannez le code-barres...";
    }
}
